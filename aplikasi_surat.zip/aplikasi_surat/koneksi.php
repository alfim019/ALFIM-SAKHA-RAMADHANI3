<?php
$konek= new mysqli ("localhost","root","","tabel_surat") or die ("error");

?>