<?php
  include "boot.php";
  session_start();
  if($_SESSION['status']!="login"){
    header("location:index.php");
  }
?>
<?php
    include "boot.php";
    include "koneksi.php";
    $no                 = $_POST['no'];
    $tgls               = $_POST['tglsuratmsk'];
    $asal_surat         = $_POST['asalsurat'];
    $nomor_surat        = $_POST['nomorsurat'];
    $tanggal_surat      = $_POST['tglsurat'];
    $perihal            = $_POST['perihal'];
    $diteruskan_kepada  = $_POST['diteruskankpd'];
    $tampung= $konek -> query("UPDATE data_surat SET tgl_masuk_surat='$tgls', asal_surat='$asal_surat', nomor_surat='$nomor_surat', tanggal_surat='$tanggal_surat', perihal='$perihal', diteruskan_kepada='$diteruskan_kepada' WHERE no='$no' ");
?>

<script>
    document.location.href='tampil.php';
</script>
