<?php
  include "boot.php";
  session_start();
  if($_SESSION['status']!="login"){
    header("location:index.php");
  }
?>
<?php include "boot.php"; ?>
<img src="SMK1.jpeg" class="rounded mx-auto d-block" alt="..." width="1350" height="800">

